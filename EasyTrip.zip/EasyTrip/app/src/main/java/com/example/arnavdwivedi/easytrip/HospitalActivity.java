package com.example.arnavdwivedi.easytrip;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

public class HospitalActivity extends AppCompatActivity {
    String selectpro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hospital);


        final Spinner hospitalselect=findViewById(R.id.select_hospital);

        final String jaipur_place[]={"ADVANCED NEUROLOGY AND SUPER SPECIALITY HOSPITAL","Mahavir Cancer Institute & Research Centre","Nims Hospital","Imperial Hospital & Research Centre ","Shubh Hospital"};
        final String udaipur_place[]={"Aravali Hospital","Goyal Hospital","Geetanjali Hospital"};
        final String bikaner_place[]={"KALRA HOSPITAL & RESEARC CENTRE KALRA MATERNITY HOME ","M.N.HOSPITAL & RESEARCH CENTRE","CHALANA HOSPITAL AND RESEARCH CENTRE"};

        final ArrayAdapter<String> ar1=new ArrayAdapter<String>(this,android.R.layout.select_dialog_item,jaipur_place);
        final ArrayAdapter<String> ar2=new ArrayAdapter<String>(this,android.R.layout.select_dialog_item,udaipur_place);
        final ArrayAdapter<String> ar3=new ArrayAdapter<String>(this,android.R.layout.select_dialog_item,bikaner_place);

        /*final Spinner places=findViewById(R.id.chosse_place);

        cityselect.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                selectpro = (String)adapterView.getSelectedItem();
                switch (selectpro) {
                    case "Jaipur":
                        places.setAdapter(ar1);
                        break;
                    case "Udaipur":
                        places.setAdapter(ar2);
                        break;
                    case "Bikaner":
                        places.setAdapter(ar3);

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });*/


        Button searchbtn=findViewById(R.id.search);
        searchbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String selectedcity=hospitalselect.getSelectedItem().toString();
                //String selectedplace=places.getSelectedItem().toString();
                Intent intent= new Intent(getApplicationContext(),Descripiton_Activity.class);
                intent.putExtra("com.example.arnavdwivedi.easytrip.city",selectedcity);
                //intent.putExtra("com.example.arnavdwivedi.easytrip.place",selectedplace);
                startActivity(intent);
            }
        });
    }
}
