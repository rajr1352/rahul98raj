package com.example.arnavdwivedi.easytrip;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class Description_1Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_description_1);

        //get intent
        Intent intent=getIntent();

        //get details like city and visiting place
        String City=intent.getStringExtra("com.example.arnavdwivedi.easytrip.city");
        String Place =intent.getStringExtra("com.example.arnavdwivedi.easytrip.place");
        String hospital=intent.getStringExtra("com.example.arnavdwivedi.easytrip.hospital");

        ArrayList<Hospital> data1 = new ArrayList<Hospital>();
        //create a hashMap
        if(City.equalsIgnoreCase("Jaipur")){
            data1.add(new Hospital("ADVANCED NEUROLOGY AND SUPER SPECIALITY HOSPITAL","The history of the hospitals goes back to 23 November 1954 when the foundation stone of the Sri Sathya Sai General Hospital, Puttaparthi was laid. The hospital was inaugurated on 4 October 1956. The hospital initially had twelve beds. It catered mainly to the local villagers and devotees who would visit Sai Baba's Prasanthi Nilayam Ashram. Treatment for in-patients and out-patients was given totally free and continues to be so to this day (as is the case with all institutions established by Sai Baba).",R.drawable.jaintemple));
            data1.add(new Hospital("Mahavir Cancer Institute & Research Centre","MCS is one of the largest cancer hospitals in the country. It has got diagnostic and therapeutic facilities under one roof. The objective of the Institute is to provide all treatment facilities with very reasonable cost. Special emphasis to provide treatment to the socio-economically weaker section of the society. The Institute is run by the experienced and well trained staff as doctors, nurses and paramedical personnel headed by an experienced Oncologist Dr. Biswajit Sanyal who is not only Oncologist but a teacher and administrator.",R.drawable.albert));
            data1.add(new Hospital("Nims Hospital  ","The Nizam's Charitable Trust in 1961 thought of starting a specialty Hospital for orthopaedic patients with an initial investment of Rs. 55 Lakhs. The foundation stone was laid on 16 July 1961 by Sri Morarji Desai, Minister for Finance, Government of India. ",R.drawable.jantar));
            data1.add(new Hospital("Imperial Hospital & Research Centre"," The adoption of a western lifestyle with its fast-food and stressful. Fast life has rewarded us with considerable economic benefits, but in its wake it has also conferred upon us such health problems as diabetes, high blood pressure, heart attacks, paralytic attacks (strokes) and cancer.",R.drawable.naharh));
            data1.add(new Hospital("Shubh Hospital  ","A hospital is a health care institution providing patient treatment with specialized medical and nursing staff and medical equipment.[1] The best-known type of hospital is the general hospital. ",R.drawable.amer));

        }else if(City.equalsIgnoreCase("udaipur")){
            data1.add(new Hospital("Aravali Hospital","Considered as the pride of Udaipur, this artificial lake was constructed under the reign of Maharana in 1960. Boating on the blue water of the lake, which is overlooked by mountains from three sides, is an experience to remember. There is a garden amidst the lake i.e. Nehru Park, which is a lovely open space with a boat-shaped restaurant. Sprawling over 2.4 kms, Fateh Sagar lake is one of the places where travellers can enjoy the scenic beauty of Udaipur. The lake lies on the northwest of the main Udaipur city.",R.drawable.fateh));
            data1.add(new Hospital("Goyal Hospital","Lake Pichola, situated in Udaipur city in the Indian state of Rajasthan, is an artificial fresh water lake, created in the year 1362 AD, named after the nearby Picholi village. ",R.drawable.pich));
            data1.add(new Hospital("Geetanjali Hospital","Udaipur City Palace is one of the architectural marvels of Rajasthan, located peacefully on the banks of Lake Pichola. This majestic City Palace is the most-visited tourist attraction of Udaipur and often distinguished as the largest palace complex in Rajasthan. Initially, Maharana Udai Singh built this superb wonder, but the present form of the Palace is the result of subsequent additions by his successors.",R.drawable.palace));

        }else if(City.equalsIgnoreCase("Bikaner")) {
            data1.add(new Hospital("KALRA HOSPITAL & RESEARC CENTRE KALRA MATERNITY HOME", " Dr. R.N. Kalra has worked in various prestigious hospitals of Delhi, including Dr. Ram Manohar Lohia Hospital (Faculty of Medicine & Cardiology). ", R.drawable.juna));
            data1.add(new Hospital("M.N.HOSPITAL & RESEARCH CENTRE ", "In the past fifteen years, the numbers of new and follow up patients have increased by about five times and thirteen times respectively. Since 1994, and afterwards, persistent efforts were made by public, philanthropic organizations, local administration and Government of Rajasthan, in order to get, S.P. Medical College & A.G. of Hospitals, Bikaner. ", R.drawable.karni));
            data1.add(new Hospital("CHALANA HOSPITAL AND RESEARCH CENTRE ", "Assuring availability of free, comprehensive primary health care services, for all aspects of reproductive, maternal, child and adolescent health and for the most prevalent communicable, non-communicable and occupational diseases in the population. ", R.drawable.gajnar));
        }



           //get this layout
        LinearLayout v1= (LinearLayout)findViewById(R.id.hospital_place_layout);
        ViewGroup.LayoutParams lp1 = new ViewGroup.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        for(Hospital hs:data1){
            TextView name = new TextView(this);
            name.setLayoutParams(lp1);
            name.setText(hs.getName());

            v1.addView(name);

            TextView description = new TextView(this);
            description.setLayoutParams(lp1);
            description.setText(hs.getDescription());
            v1.addView(description);

            ImageView myimage = new ImageView(this);
            myimage.setMaxHeight(400);
            myimage.setMaxWidth(300);
            Bitmap icon = BitmapFactory.decodeResource(getApplication().getResources(),
                    hs.getImageName());
            myimage.setImageBitmap(icon);
            v1.addView(myimage);
        }

    }
}
