package com.example.arnavdwivedi.easytrip;

/**
 * Created by Arnav Dwivedi on 7/26/2018.
 */

public class Hospital {
    String name;
    String description;
    int imageName;
    //String address

    public Hospital(String name, String description, int imageName) {
        this.name = name;
        this.description = description;
        this.imageName = imageName;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public int getImageName() {
        return imageName;
    }
}
