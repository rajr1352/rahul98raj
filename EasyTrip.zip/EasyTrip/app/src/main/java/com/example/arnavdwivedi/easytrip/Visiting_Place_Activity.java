package com.example.arnavdwivedi.easytrip;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

public class Visiting_Place_Activity extends AppCompatActivity {

    String selectpro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visiting__place_);


        final Spinner cityselect=findViewById(R.id.select_city);

        final String jaipur_place[]={"Amer","Jal Mahal","City Palace"};
        final String udaipur_place[]={"Fateh Sagar","City Palace","Pichola"};
        final String bikaner_place[]={"jhk","jgjag","/aihaskjdh"};

        final ArrayAdapter<String> ar1=new ArrayAdapter<String>(this,android.R.layout.select_dialog_item,jaipur_place);
        final ArrayAdapter<String> ar2=new ArrayAdapter<String>(this,android.R.layout.select_dialog_item,udaipur_place);
        final ArrayAdapter<String> ar3=new ArrayAdapter<String>(this,android.R.layout.select_dialog_item,bikaner_place);

        /*final Spinner places=findViewById(R.id.chosse_place);

        cityselect.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                selectpro = (String)adapterView.getSelectedItem();
                switch (selectpro) {
                    case "Jaipur":
                        places.setAdapter(ar1);
                        break;
                    case "Udaipur":
                        places.setAdapter(ar2);
                        break;
                    case "Bikaner":
                        places.setAdapter(ar3);

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });*/


        Button searchbtn=findViewById(R.id.search);
        searchbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String selectedcity=cityselect.getSelectedItem().toString();
                //String selectedplace=places.getSelectedItem().toString();
                Intent intent= new Intent(getApplicationContext(),Descripiton_Activity.class);
                intent.putExtra("com.example.arnavdwivedi.easytrip.city",selectedcity);
                //intent.putExtra("com.example.arnavdwivedi.easytrip.place",selectedplace);
                startActivity(intent);
            }
        });
    }
}
