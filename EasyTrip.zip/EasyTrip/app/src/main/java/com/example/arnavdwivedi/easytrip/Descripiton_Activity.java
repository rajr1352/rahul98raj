package com.example.arnavdwivedi.easytrip;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class Descripiton_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_descripiton_);

        //get intent
        Intent intent=getIntent();

        //get details like city and visiting place
        String City=intent.getStringExtra("com.example.arnavdwivedi.easytrip.city");
        String Place =intent.getStringExtra("com.example.arnavdwivedi.easytrip.place");
        String hospital=intent.getStringExtra("com.example.arnavdwivedi.easytrip.hospital");
        /*//show city in TextView
        TextView citytxt=findViewById(R.id.city);
        citytxt.setText(City);

        //show visiting place in TextView
        TextView  placetxt=findViewById(R.id.place);
        placetxt.setText(Place);*/

        ArrayList<VisitingPlaceData> data = new ArrayList<VisitingPlaceData>();
        //create a hashMap
        if(City.equalsIgnoreCase("Jaipur")){
            data.add(new VisitingPlaceData("Jal Mahal","Jal Mahal(meaning water palace) is a place in the middle if the man sagar Lake in jaipur city.the capital of the state of the rajisthan.",R.drawable.jalmahal));
            data.add(new VisitingPlaceData("Albert hall","The building of Albert Hall Museum was built in 1876 as a concert hall. The museum gets its name from the Victoria and Albert Museum of London, because of the similarity of architecture.",R.drawable.albert));
            data.add(new VisitingPlaceData("Jantar Mantar","In the early 18th century Maharaja Sawai Jai Singh II of Jaipur constructed five Jantar Mantar in total in New Delhi, Jaipur, Ujjain, Mathura and Varanasi. ",R.drawable.jantar));
            data.add(new VisitingPlaceData("Nahargarh Fort","Located in the Pink City of Jaipur is the Nahargarh Fort, which is one of the many countless palaces and beautiful historic buildings that speak of the magnificent and rich history of this city.",R.drawable.naharh));
            data.add(new VisitingPlaceData("Amer Fort","The Amer Fort, situated in Amber, 11 kilometers from Jaipur, is one of the most famous forts of Rajasthan. Amer, originally, was the capital of the state before Jaipur. ",R.drawable.amer));
            data.add(new VisitingPlaceData("City Palace","City Palace, Jaipur, which includes the Chandra Mahal and Mubarak Mahal palaces and other buildings, is a palace complex in Jaipur, the capital of the Rajasthan state, India",R.drawable.city));
        }else if(City.equalsIgnoreCase("udaipur")){
            data.add(new VisitingPlaceData("Fateh Sagar","Considered as the pride of Udaipur, this artificial lake was constructed under the reign of Maharana in 1960. Boating on the blue water of the lake, which is overlooked by mountains from three sides, is an experience to remember. There is a garden amidst the lake i.e. Nehru Park, which is a lovely open space with a boat-shaped restaurant. Sprawling over 2.4 kms, Fateh Sagar lake is one of the places where travellers can enjoy the scenic beauty of Udaipur. The lake lies on the northwest of the main Udaipur city.",R.drawable.fateh));
            data.add(new VisitingPlaceData("Pichola Lake","Lake Pichola, situated in Udaipur city in the Indian state of Rajasthan, is an artificial fresh water lake, created in the year 1362 AD, named after the nearby Picholi village. ",R.drawable.pich));
            data.add(new VisitingPlaceData("City Palace","Udaipur City Palace is one of the architectural marvels of Rajasthan, located peacefully on the banks of Lake Pichola. This majestic City Palace is the most-visited tourist attraction of Udaipur and often distinguished as the largest palace complex in Rajasthan. Initially, Maharana Udai Singh built this superb wonder, but the present form of the Palace is the result of subsequent additions by his successors.",R.drawable.palace));
            data.add(new VisitingPlaceData("Saheliyon ki bari","Udaipur City Palace is one of the architectural marvels of Rajasthan, located peacefully on the banks of Lake Pichola. This majestic City Palace is the most-visited tourist attraction of Udaipur and often distinguished as the largest palace complex in Rajasthan. Initially, Maharana Udai Singh built this superb wonder, but the present form of the Palace is the result of subsequent additions by his successors.",R.drawable.saheli));
            data.add(new VisitingPlaceData("Gulab bagh","Sajjan Niwas Garden is the largest garden of Rajasthan, sprawled over 100 acres of land. During 1850's, Maharana Sajjan Singh took the initiative to built this beautiful garden. Sajjan Niwas Bagh is celebrated for its numerous varieties of roses. Due to abundance of rose flowers, this garden is also known as Gulab Bagh or Rose Garden. Situated right beneath the banks of Pichola Lake on Lake Palace Road, Gulab Bagh is an interesting park in the southeast of City Palace complex",R.drawable.gulab));

        }else if(City.equalsIgnoreCase("Bikaner")) {
            data.add(new VisitingPlaceData("Junagarh Fort", "The erstwhile Princely state of Bikaner and its capital city Bikaner was founded by Rao Bika (1465-1504 AD.) by the blessings of Goddess Karni Mata in the year 1488 AD. In those days this vast tract of desert country was called “Jangaldesh”. Prince Bika of the Rathore clan of Rajputs was the valiant son of Rao Jodha- the founder of Jodhpur. ", R.drawable.juna));
            data.add(new VisitingPlaceData("Karni Mata Temple", "The erstwhile Princely state of Bikaner and its capital city Bikaner was founded by Rao Bika (1465-1504 AD.) by the blessings of Goddess Karni Mata in the year 1488 AD. In those days this vast tract of desert country was called “Jangaldesh”. Prince Bika of the Rathore clan of Rajputs was the valiant son of Rao Jodha- the founder of Jodhpur. ", R.drawable.karni));
            data.add(new VisitingPlaceData("Gajner Palace", "The Gajner Palace in Bikaner is a jewel in the Thar Desert. It was built by His Highness Maharaja Sir Ganga Singh of Bikaner on the shores of a lake. The majestic palace is spread over 6000 acres. The charm of the palace is its, fabulous setting and unhurried way of life. One can explore a world of pleasant nature-walks, boat rides on the lake, sanctuary dinners and desert safaris. One of Rajasthan’s ‘best-kept secret’, Gajner is just 30-minutes’ drive away from the city of Bikaner.", R.drawable.gajnar));
            data.add(new VisitingPlaceData("Lallgarh Palace", "One of the most popular heritage hotels in Bikaner, Lalgarh Palace is known for the most intricate stone carving on red stone and its grand Indo-Saracenic architecture. Spread in verdant gardens with dancing peacocks, open courtyards and vibrant bougainvillea flowers, this heritage hotels offer its guests, a memorable stay. Built in the end of the 19th century, the hotel has huge, well-fitted guest rooms and suites. While the decor is regal, the services are world-class.", R.drawable.lalagarh));
            data.add(new VisitingPlaceData("Jain Temple Bhandasar", "Jain temple is one of the oldest temples in Bikaner, and was built in the 15th century. It is decorated with mirror work, frescoes and leaf paintings. The temple is built of red sandstone and is divided into three floors. One can see the skyline of Bikaner by climbing to the topmost floor of this temple. It is believed that the temple was made with 40,000 kilograms of ghee instead of mortar, which locals insist seeps through the walls on hot days.", R.drawable.jaintemple));
        }


        //get this layout
        LinearLayout v = (LinearLayout)findViewById(R.id.visiting_place_layout);
        ViewGroup.LayoutParams lp = new ViewGroup.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        for(VisitingPlaceData vpd:data){
            TextView name = new TextView(this);
            name.setLayoutParams(lp);
            name.setText(vpd.getName());

            v.addView(name);

            TextView description = new TextView(this);
            description.setLayoutParams(lp);
            description.setText(vpd.getDescription());
            v.addView(description);

            ImageView myimage = new ImageView(this);
            myimage.setMaxHeight(400);
            myimage.setMaxWidth(300);
            Bitmap icon = BitmapFactory.decodeResource(getApplication().getResources(),
                    vpd.getImageName());
            myimage.setImageBitmap(icon);
            v.addView(myimage);
        }

    }
}