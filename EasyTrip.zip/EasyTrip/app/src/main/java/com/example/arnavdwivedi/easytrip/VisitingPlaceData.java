package com.example.arnavdwivedi.easytrip;

/**
 * Created by KAPIL on 24-07-2018.
 */

public class VisitingPlaceData {
    String name;
    String description;
    int imageName;
    //String address

    public VisitingPlaceData(String name, String description, int imageName) {
        this.name = name;
        this.description = description;
        this.imageName = imageName;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public int getImageName() {
        return imageName;
    }
}
